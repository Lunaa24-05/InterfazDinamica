//js para el juego de atrapar flores
import { iniciarSesion, cargarJSON } from "./sesion.js";
import { Canasta, Flor } from "./figuras.js";

const canvas = document.querySelector('canvas');
const ctx = canvas.getContext('2d');

// Estado del juego
let juegoEnCurso = false;
let puntaje = 0;
let usuario = 'Invitado';

// Objetos del juego
let canasta = null;
let flores = [];

// Control del bucle de dibujo
let rafId = null;

// Contador para generar flores
let contadorFlores = 0;
const intervaloFlores = 30; // cada 30 frames generar una flor

// Event listeners
document.querySelector('#boton_empezar').addEventListener('click', iniciarJuego);
document.querySelector('#boton-reiniciar').addEventListener('click', reiniciarJuego);
document.querySelector('#boton_iniciar_sesion')?.addEventListener('click', iniciarSesion);

canvas.addEventListener('mousemove', (event) => {
    if (juegoEnCurso && canasta) {
        const rect = canvas.getBoundingClientRect();
        const x = event.clientX - rect.left;
        canasta.moverAlMouse(x);
    }
});

// Función para iniciar el juego
function iniciarJuego() {
    if (!juegoEnCurso) {
        juegoEnCurso = true;
        puntaje = 0;
        flores = [];
        contadorFlores = 0;

        // Crear una nueva canasta
        canasta = new Canasta(canvas);

        // Iniciar bucle de dibujo
        if (!rafId) gameLoop();

        console.log('Juego iniciado');
    }
}

// Función para reiniciar el juego
function reiniciarJuego() {
    juegoEnCurso = false;
    puntaje = 0;
    flores = [];
    contadorFlores = 0;
    canasta = null;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    document.getElementById('puntaje').textContent = puntaje;

    // Detener loop de dibujo
    if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
    }

    console.log('Juego reiniciado');
}

// Función para terminar el juego (cuando se pierde una flor)
function terminarJuego() {
    juegoEnCurso = false;
    console.log('Juego terminado - ¡Perdió una flor!');
    alert(`Juego Terminado\nPuntaje final: ${puntaje}`);
    
    if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
    }
}

// Función para generar una nueva flor
function generarFlor() {
    const flor = new Flor(canvas);
    flores.push(flor);
}

// Bucle principal de dibujo y actualización
function gameLoop() {
    rafId = requestAnimationFrame(gameLoop);

    // Limpiar canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (juegoEnCurso) {
        // Generar flores a intervalos
        contadorFlores++;
        if (contadorFlores >= intervaloFlores) {
            generarFlor();
            contadorFlores = 0;
        }

        // Actualizar y dibujar flores
        for (let i = flores.length - 1; i >= 0; i--) {
            const flor = flores[i];

            // Actualizar posición de la flor
            flor.actualizar();

            // Dibujar flor
            flor.dibujar(ctx);

            // Detectar colisión con la canasta
            if (canasta && canasta.colisionaCon(flor)) {
                // Flor atrapada
                flores.splice(i, 1);
                puntaje += 10;
                document.getElementById('puntaje').textContent = puntaje;
                console.log(`¡Flor atrapada! Puntaje: ${puntaje}`);
            } else if (flor.estaFueera()) {
                // Flor no atrapada - FIN DEL JUEGO
                terminarJuego();
            }
        }

        // Dibujar canasta
        if (canasta) {
            canasta.dibujar(ctx);
        }
    }
}
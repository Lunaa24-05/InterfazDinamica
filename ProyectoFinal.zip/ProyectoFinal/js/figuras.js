// Clase base para todas las figuras del juego
export class Figura {
    constructor(x, y, ancho, alto) {
        this.x = x;
        this.y = y;
        this.ancho = ancho;
        this.alto = alto;
    }

    // Método que debe ser implementado por las subclases
    dibujar(ctx) {
        throw new Error('El método dibujar() debe ser implementado por la subclase');
    }

    // Método para obtener los límites de la figura (útil para colisiones)
    obtenerLimites() {
        return {
            izquierda: this.x,
            derecha: this.x + this.ancho,
            arriba: this.y,
            abajo: this.y + this.alto
        };
    }
}

// Clase Canasta que hereda de Figura
export class Canasta extends Figura {
    constructor(canvas) {
        super(0, 0, 100, 120);
        this.canvas = canvas;
        this.imagen = new Image();
        this.imagen.src = 'recursos/canasta_png.png';
        this.imagenCargada = false;
        this.imagen.onload = () => {
            this.imagenCargada = true;
        };
        this.imagen.onerror = () => {
            console.warn('No se pudo cargar la imagen de la canasta');
        };
        // Inicializar en el centro inferior del canvas
        this.resetearPosicion();
    }

    resetearPosicion() {
        this.x = (this.canvas.width / 2) - (this.ancho / 2);
        this.y = this.canvas.height - this.alto - 10;
    }

    moverAlMouse(posX) {
        // Centrar la canasta en la posición del ratón
        this.x = posX - (this.ancho / 2);
        // Límites para que no salga del canvas
        if (this.x < 0) this.x = 0;
        if (this.x + this.ancho > this.canvas.width) {
            this.x = this.canvas.width - this.ancho;
        }
    }

    dibujar(ctx) {
        if (this.imagenCargada) {
            // Dibujar la imagen escalada al tamaño de this.ancho x this.alto
            ctx.drawImage(this.imagen, this.x, this.y, this.ancho, this.alto);
        } else {
            // Dibujar un placeholder mientras carga la imagen
            ctx.fillStyle = '#8B4513';
            ctx.fillRect(this.x, this.y, this.ancho, this.alto);
            ctx.fillStyle = '#654321';
            ctx.font = '12px Arial';
            ctx.fillText('Cesta', this.x + 5, this.y + 20);
        }
    }

    // Detectar colisión con una flor (AABB - Axis-Aligned Bounding Box)
    colisionaCon(flor) {
        const limitesCanasta = this.obtenerLimites();
        const limitesFlor = flor.obtenerLimites();

        return !(
            limitesCanasta.derecha < limitesFlor.izquierda ||
            limitesCanasta.izquierda > limitesFlor.derecha ||
            limitesCanasta.abajo < limitesFlor.arriba ||
            limitesCanasta.arriba > limitesFlor.abajo
        );
    }
}

// Clase Flor que hereda de Figura
export class Flor extends Figura {
    constructor(canvas) {
        super(0, 0, 48, 48);
        this.canvas = canvas;
        this.velocidad = 3; // píxeles por frame
        this.imagen = new Image();
        this.imagen.src = 'recursos/florJuego_png.png';
        this.imagenCargada = false;
        this.imagen.onload = () => {
            this.imagenCargada = true;
            // NO actualizamos ancho/alto, mantenemos los valores iniciales
        };
        this.imagen.onerror = () => {
            console.warn('No se pudo cargar la imagen de la flor');
        };
        // Inicializar en posición aleatoria en la parte superior
        this.inicializar();
    }

    inicializar() {
        // Posición X aleatoria en el canvas
        this.x = Math.random() * (this.canvas.width - this.ancho);
        // Posición Y en la parte superior (fuera del canvas)
        this.y = -this.alto;
    }

    actualizar() {
        // Mover la flor hacia abajo
        this.y += this.velocidad;
    }

    estaFueera() {
        // Retorna true si la flor ha caído fuera del canvas
        return this.y > this.canvas.height;
    }

    dibujar(ctx) {
        if (this.imagenCargada) {
            // Dibujar la imagen escalada al tamaño de this.ancho x this.alto
            ctx.drawImage(this.imagen, this.x, this.y, this.ancho, this.alto);
        } else {
            // Placeholder: círculo amarillo
            ctx.fillStyle = '#FFD700';
            ctx.beginPath();
            ctx.arc(this.x + this.ancho / 2, this.y + this.alto / 2, this.ancho / 2, 0, Math.PI * 2);
            ctx.fill();
        }
    }
}

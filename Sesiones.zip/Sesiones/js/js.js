//que el usuario llene los datos del formulario y los envie
const formularioInicioSesion = document.querySelector('.formulario-inicio-sesion');
formularioInicioSesion.addEventListener('submit', function(event) {
    event.preventDefault(); // el envio del formulario
    const correo = formularioInicioSesion.correo.value;
    const contrasena = formularioprevenirInicioSesion.contrasena.value;
    console.log('Correo:', correo);
    console.log('Contrasena:', contrasena);
    //aqui puedes agregar
    //  la logica para autenticar al usuario
}
);
 